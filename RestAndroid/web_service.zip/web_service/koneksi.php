<?php
 define('HOST','localhost');
 define('USER','id12789027_kita');
 define('PASS','123456');
 define('DB','id12789027_bajukita');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');